ONLINE STATION AND COMPUTER SOLUTION — PVC CARD WEBSITE

Files:
- index.html: complete responsive website. No paid software or external libraries required.

FREE PUBLISHING OPTION: GITHUB PAGES
1. Go to https://github.com/ and create/sign in to a free account.
2. Create a new public repository, for example: online-station-pvc.
3. Upload index.html to the repository root.
4. Open repository Settings → Pages.
5. Under Build and deployment, choose “Deploy from a branch”.
6. Select branch “main” and folder “/ (root)”, then Save.
7. Wait for the published URL shown in the Pages section. It will usually look like:
   https://YOUR-USERNAME.github.io/online-station-pvc/

EDITING:
- Open index.html in Notepad or a code editor to change text, prices, contact information, or services.
- WhatsApp number is set to 918055549280 in international format (India +91).
- The catalog uses generic decorative card mockups, not official government card designs or real personal data.
- Delivery, COD, pricing, and working hours are not promised as fixed; confirm details with the shop before publishing claims.
- For safety and privacy, do not ask customers to send more personal data than necessary. Official Aadhaar PVC cards should be ordered through the official UIDAI service where applicable.

You can test the site by double-clicking index.html on your computer.
